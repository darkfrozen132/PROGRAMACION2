/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   ColaGenerica.h
 * Author: Leoncio
 *
 * Created on 6 de mayo de 2024, 05:48 PM
 */

#ifndef COLAGENERICA_H
#define COLAGENERICA_H

void generacola(void*&col);
void encola(void*&col,void*reg);
void* desencola(void*&col);
bool colavacia(void*col);

#endif /* COLAGENERICA_H */

